class Usuario {
  constructor(usuario, contraseña) {
    this.usuario = usuario;
    this.contraseña = contraseña;
  }
}

module.exports = Usuario;
